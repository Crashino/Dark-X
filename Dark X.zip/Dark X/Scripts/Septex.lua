--This Script was not made by Domsoi. All credits go to the owner.
loadstring(game:HttpGet(('https://raw.githubusercontent.com/XTheMasterX/Scripts/Main/PrisonLife'),true))()